package exploris.gui;
/**
* GUITracker
*
* @author: Stephan Jamieson
*
* @version: 1.0
* date: 12.08.2003
*
*/
import exploris.motion.Tracker;
//
public interface GUITracker extends Tracker  { }
