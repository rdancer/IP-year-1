package exploris.motion;
/**
* Movement
*
* @author: Stephan Jamieson
*
* @version: 1.0
* date: 12.08.2003
*
*/
public abstract class Movement {

    public abstract Position applyTo(Position position);

}
    
