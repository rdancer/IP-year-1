package exploris.motion;
/**
* Tracker
*
* @author: Stephan Jamieson
*
* @version: 1.0
* date: 12.08.2003
*
*/
public interface Tracker {


    void update(MobileObject object, Movement movement);

}
